# WhatsApp Bot

Bot de atendimento automático para WhatsApp usando a WhatsApp Cloud API.

## Instalação

```bash
npm install
```

Crie `.env` a partir de `.env.example` e configure as credenciais.

## Executar

```bash
npm start
```

O servidor usa a porta definida em `PORT` ou 3000 por padrão.

## Webhook

A rota do webhook é:

`/webhook`

Não publique o arquivo `.env` nem tokens reais no GitHub.
