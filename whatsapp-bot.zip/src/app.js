const express = require("express");

const webhookRoutes = require("./routes/webhookRoutes");

const app = express();

app.use(express.json());

app.get("/", (req, res) => {
  res.status(200).json({
    status: "online",
    message: "Bot WhatsApp funcionando"
  });
});

app.use("/webhook", webhookRoutes);

module.exports = app;
