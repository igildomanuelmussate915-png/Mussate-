const botService = require("../services/botService");

function verifyWebhook(req, res) {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (
    mode === "subscribe" &&
    token === process.env.VERIFY_TOKEN
  ) {
    console.log("Webhook verificado com sucesso.");
    return res.status(200).send(challenge);
  }

  return res.sendStatus(403);
}

async function receiveWebhook(req, res) {
  try {
    console.log("Webhook recebido.");

    await botService.processWebhook(req.body);

    return res.sendStatus(200);
  } catch (error) {
    console.error("Erro ao processar webhook:", error);
    return res.sendStatus(500);
  }
}

module.exports = {
  verifyWebhook,
  receiveWebhook
};
