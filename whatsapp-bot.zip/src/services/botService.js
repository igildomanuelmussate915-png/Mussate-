const whatsappService = require("./whatsappService");

const processedMessageIds = new Set();

async function processWebhook(body) {
  if (!body || body.object !== "whatsapp_business_account") {
    return;
  }

  const entries = body.entry || [];

  for (const entry of entries) {
    const changes = entry.changes || [];

    for (const change of changes) {
      const value = change.value;

      if (!value || !value.messages) {
        continue;
      }

      for (const message of value.messages) {
        await processMessage(message);
      }
    }
  }
}

const optionHandlers = {
  oi: () => getMainMenu(),
  olá: () => getMainMenu(),
  ola: () => getMainMenu(),
  menu: () => getMainMenu(),
  "1": () =>
    "📚 INFORMAÇÕES\n\n" +
    "Aqui você poderá colocar as informações " +
    "sobre o seu negócio ou projeto.",
  "2": () =>
    "🛒 PRODUTOS\n\n" +
    "Aqui serão apresentados os seus produtos ou serviços.",
  "3": () =>
    "💬 ATENDIMENTO\n\n" +
    "Um atendente poderá continuar o atendimento.",
  "4": () =>
    "📞 CONTACTOS\n\n" +
    "Telefone: coloque o seu número\n" +
    "WhatsApp: coloque o seu WhatsApp"
};

async function processMessage(message) {
  const messageId = message.id;

  if (!messageId || processedMessageIds.has(messageId)) {
    return;
  }

  processedMessageIds.add(messageId);

  try {
    if (message.type !== "text") {
      return;
    }

    const from = message.from;
    const text = message.text?.body?.trim().toLowerCase();

    if (!from || !text) {
      return;
    }

    const response = optionHandlers[text]
      ? optionHandlers[text]()
      : "Não consegui identificar a sua opção.\n\n" + getMainMenu();

    await whatsappService.sendTextMessage(from, response);
  } catch (error) {
    processedMessageIds.delete(messageId);
    throw error;
  }
}

function getMainMenu() {
  return (
    "👋 Olá! Seja bem-vindo ao nosso WhatsApp.\n\n" +
    "Escolha uma opção:\n\n" +
    "1️⃣ Informações\n" +
    "2️⃣ Produtos\n" +
    "3️⃣ Atendimento\n" +
    "4️⃣ Contactos\n\n" +
    "Envie o número da opção desejada."
  );
}

module.exports = {
  processWebhook
};
