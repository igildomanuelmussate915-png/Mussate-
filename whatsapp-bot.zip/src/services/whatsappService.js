const API_VERSION = process.env.GRAPH_API_VERSION || "v23.0";

async function sendTextMessage(to, message) {
  const phoneNumberId = process.env.PHONE_NUMBER_ID;
  const token = process.env.WHATSAPP_TOKEN;

  if (!phoneNumberId) {
    throw new Error("PHONE_NUMBER_ID não configurado.");
  }

  if (!token) {
    throw new Error("WHATSAPP_TOKEN não configurado.");
  }

  if (!to) {
    throw new Error("Número do destinatário não informado.");
  }

  if (!message) {
    throw new Error("Mensagem não informada.");
  }

  const url =
    `https://graph.facebook.com/${API_VERSION}/` +
    `${phoneNumberId}/messages`;

  const payload = {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to,
    type: "text",
    text: {
      preview_url: false,
      body: message
    }
  };

  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json();

  if (!response.ok) {
    console.error("Erro da WhatsApp Cloud API:", data);

    throw new Error(
      data?.error?.message ||
      "Erro ao enviar mensagem pelo WhatsApp."
    );
  }

  console.log(`Mensagem enviada com sucesso para ${to}.`);

  return data;
}

module.exports = {
  sendTextMessage
};
